from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import get_user_model
import re


class CustomUserCreationForm(forms.Form):
    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su correo electrónico',
                'required': True,
                'pattern': '^[0-9]{5}tn[0-9]{3}@utez\.edu\.mx$',
                'title': 'Solo se aceptan correos pertenecientes a la UTEZ'
            }
        )
    )
    name = forms.CharField(
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su nombre completo',
                'required': True
            }
        )
    )
    surname = forms.CharField(
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su apellido',
                'required': True
            }
        )
    )
    control_number = forms.CharField(
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su matrícula',
                'required': True,
                'pattern': '^[0-9]{5}tn[0-9]{3}$',
                'title': 'La matrícula debe tener 5 dígitos seguidos de "tn" y 3 dígitos'
            }
        ),
     
    )
    tel = forms.CharField(
        max_length=10,  # Validación de longitud de teléfono
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese tu número de teléfono',
                'required': True,
                'title': 'El teléfono debe tener exactamente 10 dígitos'
            }
        )
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese tu contraseña',
                'required': True
            }
        )
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Confirma tu contraseña',
                'required': True
            }
        )
    )

    widgets = {
        'email': forms.EmailInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su correo electrónico',
                'required': True,
                'pattern': '^[0-9]{5}tn[0-9]{3}@utez\.edu\.mx$',
                'title': 'Solo se aceptan correos pertenecientes a la UTEZ'
            }
        ),
        'name': forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su nombre completo',
                'required': True
            }
        ),
        'control_number': forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese su matrícula',
                'required': True,
                'pattern': '^[0-9]{5}tn[0-9]{3}$',
                'title': 'La matrícula debe tener 5 dígitos seguidos de "tn" y 3 dígitos'
            }
        ),
        'tel': forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese tu número de teléfono',
                'required': True,
                'title': 'El teléfono debe tener exactamente 10 dígitos'
            }
        ),
        'password1': forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese tu contraseña',
                'required': True
            }
        ),
        'password2': forms.PasswordInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Confirma tu contraseña',
                'required': True
            }
        )
    }

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")

        password_regex = r'^(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&?])[A-Za-z\d!#$%&?]{8,}$'
        if not re.match(password_regex, password1):
            raise forms.ValidationError("La contraseña debe tener al menos 8 caracteres, 1 número, 1 letra mayúscula y 1 carácter especial (!, #, $, %, & o ?).")

        return cleaned_data


class CustomUserLoginForm(AuthenticationForm):
    def clean(self):
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')
        return super().clean()