from django import forms
from .models import Producto

#Podemos crear un formulario para cada modelo que exista
class productoForm(forms.ModelForm):
    #La clase meta (MetaInfo del Formulario)
    class Meta:

        #Definir de que modelo se  basa el formulario
        model = Producto

        #Definir que campos van a ser incluidos en el formulario
        fields = ['nombre', 'precio', 'imagen']

        #Definir como se deben de ver o que atributos tienen los campos
        widgets = {
            'nombre': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'Nombre del Producto'
                }
            ),
            'precio': forms.NumberInput(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'Precio del Producto'
                }
            ),
            'imagen': forms.URLInput(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'URL de la Imagen del Producto'
                }
            )
        }

        #Etiquetas personalizadas
        labels = {
            'nommbre' : 'Nombre del Producto',
            'precio' : 'Precio (MXN)',
            'imagen' : 'URL de la Imagen'
        }

        #Mensajes de error personalizados
        error_messages = {
            'nombre': {
                'required' : 'El nombre es obligatorio'
            },
            'precio' :{
                'required' : 'El precio no puede estar vacio',
                'invalid' : 'Ingrese un número valido'
            }
        }
